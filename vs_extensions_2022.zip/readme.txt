
EditorGuidelines.vsix
https://marketplace.visualstudio.com/items?itemName=PaulHarrington.EditorGuidelines

InsallerProjects.vsix
https://marketplace.visualstudio.com/items?itemName=VisualStudioClient.MicrosoftVisualStudio2022InstallerProjects

MarkdownEditor2022.vsix
https://github.com/MadsKristensen/MarkdownEditor2022

SonarLint.VSIX-6.9.0.54300-2022.vsix
https://marketplace.visualstudio.com/items?itemName=SonarSource.SonarLintforVisualStudio2022

SpecFlow.VisualStudio.Package.vsix
https://marketplace.visualstudio.com/items?itemName=TechTalkSpecFlowTeam.SpecFlowForVisualStudio2022

VSColorOuptut64
https://marketplace.visualstudio.com/items?itemName=MikeWard-AnnArbor.VSColorOutput64


